import tkinter as tk
import webbrowser
import keyboard

def open_website():
    webbrowser.open("https://zdside.github.io/")
    root.quit()

keyboard.block_key('windows')
keyboard.block_key('ctrl')
keyboard.block_key('alt')
keyboard.block_key('tab')

root = tk.Tk()
root.title("Black Screen")
root.attributes("-fullscreen", True)
root.configure(bg='black')

label = tk.Label(root, text="https://zdside.github.io", fg="white", bg="black", font=("Helvetica", 50))
label.pack(expand=True)

ok_button = tk.Button(root, text="OK", fg="black", bg="white", font=("Helvetica", 20), command=open_website)
ok_button.pack(pady=20)

root.mainloop()